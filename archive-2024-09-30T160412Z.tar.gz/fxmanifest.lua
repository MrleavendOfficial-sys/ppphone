fx_version 'cerulean'

game 'gta5'

author 'RoadToSix'
description 'RoadPhone FiveM Phone'
version '0.4.2'

ui_page 'html/index.html'

files {
    'html/fonts/fontawesome-free-6.0.0-beta3-web/**/*.**',
    'html/fonts/fontawesome-free-6.0.0-beta3-web/**/**/.**',
    'html/index.html',
    'js/*.js',
    'node_modules/jsonfile/*.js',
    'apps/*.js',
    'config/*.json',
    'html/img/backgrounds/*.png',
    'html/img/backgrounds/*.jpg',
    'html/img/backgrounds/*.gif',
    'html/img/icons/*.png',
    'html/css/*.css',
    'html/sound/*.ogg',
    'html/img/iphone13.png',
    'html/img/background.jpg',
    'html/img/icons/app/*.png',
    "lib/*.lua"
}

shared_scripts {
    "lib/utils.lua"
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    "config/API.lua",
    'config/apikeys.lua',
    'config/config.lua',
    "server/server.lua",
    'server/bank.lua',
    '@es_extended/locale.lua',
}

client_scripts {
    "@es_extended/locale.lua",
    "lib/proxy.lua",
    "lib/tunnel.lua",
    'config/config.lua',
    'config/apps.json',
    "client/openanimation.lua",
    'client/bank.lua',
    "client/client.lua",
    'client/camera.lua',
    'client/appstore.lua',
    'client/openphone.lua'
}

dependencies {
    'es_extended',
	'oxmysql',
    'screenshot-basic',
    'utk_render'
}

escrow_ignore {
    'config/config.lua',
    "client/openanimation.lua",
    'client/openphone.lua',
    'client/camera.lua',
    'config/API.lua',
    'lib/*.lua'
}

lua54 'yes'
dependency '/assetpacks'