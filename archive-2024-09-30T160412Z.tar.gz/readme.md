Discord: dsc.gg/roadphone

Solltest du bei irgendetwas Hilfe brauchen bitte eröffne ein Ticket im Discord

Installation:

WICHTIG: Setze in der server.cfg beim "mysql_connection_string" unbedingt noch ";charset=utf8mb4" dahinter damit Emojis funktionieren.
WICHTIG: Wenn du von einem anderen Handy zu RoadPhone wechselst bitte lösch unbedingt die Tabelle: phone_number in users und setze sie neu ein durch die all.sql
WICHTIG: Wenn du von 0.3 auf 0.4 wechselst und esx_ambulancejob benutzst bitte ersetze den unten genannten Code im Skript esx_ambulancejob

1. Dowloade alle Skripts von unserem Discord im #requirements Kanal und ziehe die Scripts in deinen resource Ordner, starte sie in dieser Reihenfolge!

start oxmysql
start screenshot-basic
start utk_render
start roadphone

2. Füge all.sql in deine SQL hinzu, wenn du von 0.3 updatest 0.4.sql.
3. Konfiguriere Config.lua + config.json + apps.json
4. Konfiguriere API.lua (trage deine Discord Webhooks dort ein)
5. Wenn du möchtest das im AmbulanceJob eine Nachricht gesendet wird sobald der Spieler tot ist und eine Taste drückt:

Gehe in <esx_ambulancejob> dann <client> dann <main.lua>

Suche nach SendDistressSignal() und ändere es zu

```lua
function SendDistressSignal()
	local playerPed = PlayerPedId()
	local coords    = GetEntityCoords(playerPed)
	local position = {x = coords.x, y = coords.y, z = coords.z}
    local anonym = false

    TriggerServerEvent("roadphone:sendDispatch", GetPlayerServerId(PlayerId()), "Verletzte Person", "yourambulancejobname", position, anonym)
end

```

Bitte ändere "yourambulancejobname" zu deinem Ambulancejob namen ab

6.Du willst das dein Job in der Job app angezeigt wird? Gehe in die **jobs** SQL und ändere **jobsapp** auf 1 und starte das Skript neu.

7.Du willst eigene Notifications einbringen zb wenn du kein Handy hast? Das geht ganz einfach gehe in die openphone.lua und ändere Dort die Zeilen ab wie du sie haben willst:

```lua


RegisterNUICallback('notification', function(data)

    local text = data.text

    --Ersetze ESX.ShowNotification durch deine eigene Funktion/Methode wenn du möchtest das deine eigenen Notifications kommen.

    ESX.ShowNotification(text)
end)

RegisterNetEvent('roadphone:sendOffNotification')
AddEventHandler('roadphone:sendOffNotification', function(text)

    
    --Ersetze ESX.ShowNotification durch deine eigene Funktion/Methode wenn du möchtest das deine eigenen Notifications kommen.

    ESX.ShowNotification(text)
end)

```
Falls du kein Item hast was "phone" heißt bitte erstelle eins in der Datenbank.
