function startRoadPhoneRendering() {
    const canvas = document.getElementById("phone-camera-canvas");
    canvas.style.display = "block"
    MainRender.renderToTarget(canvas);
}

function stopRoadPhoneRendering() {
    MainRender.stop();
}
