import { EmojiButton } from 'https://cdn.jsdelivr.net/npm/@joeattardi/emoji-button@4.6.2';

const yellowpagepicker = new EmojiButton({ autoHide: false });
const yellowpagetrigger = document.querySelector('.phone-yellow-page-emojimenu');

yellowpagepicker.on('emoji', selection => {
    $('#phone-yellowpage-addpage-text').val(function (i, text) {
        return text + selection.emoji;
    });
});

yellowpagetrigger.addEventListener('click', () => yellowpagepicker.togglePicker(yellowpagetrigger));

const messageapppicker = new EmojiButton({
     autoHide: false,
     position: {
        top: '48vh',
        right: '37vh'
      }
    });
const messageapptrigger = document.querySelector('.phone-messages-emojimenu');

messageapppicker.on('emoji', selection => {
    $('#phone-messages-chat-input').val(function (i, text) {
        return text + selection.emoji;
    });
});

messageapptrigger.addEventListener('click', () => messageapppicker.togglePicker(messageapptrigger));
