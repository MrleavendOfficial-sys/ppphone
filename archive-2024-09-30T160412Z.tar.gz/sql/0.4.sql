CREATE TABLE IF NOT EXISTS `roadphone_bank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(50) NOT NULL DEFAULT '0',
  `receiver` varchar(50) NOT NULL DEFAULT '0',
  `amount` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `roadphone_jobs`;
CREATE TABLE IF NOT EXISTS `roadphone_jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(50) NOT NULL,
  `jobreceived` varchar(50) NOT NULL,
  `message` varchar(80) NOT NULL DEFAULT '0',
  `date` varchar(50) NOT NULL,
  `gps` varchar(500) DEFAULT '0',
  `status` int(2) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=200 DEFAULT CHARSET=utf8;

ALTER TABLE `roadphone_yellowapp` MODIFY `date` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL;
ALTER TABLE `roadphone_contacts` MODIFY `firstname` varchar(12) NOT NULL DEFAULT '0';
ALTER TABLE `roadphone_contacts` MODIFY `lastname` varchar(12) NOT NULL DEFAULT '0';
ALTER TABLE `roadphone_information` ADD lockscreen INT(2) DEFAULT '1';
DROP TABLE IF EXISTS `roadphone_apps`;


ALTER TABLE `roadphone_messages` MODIFY `message` varchar(250) NOT NULL DEFAULT '0';
ALTER TABLE `roadphone_information` ADD profilepicture LONGTEXT DEFAULT NULL;
ALTER TABLE `roadphone_messages` MODIFY `date` varchar(80) NOT NULL;
CREATE TABLE IF NOT EXISTS `roadphone_calls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `caller` varchar(50) DEFAULT NULL,
  `receiver` varchar(50) DEFAULT NULL,
  `date` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
