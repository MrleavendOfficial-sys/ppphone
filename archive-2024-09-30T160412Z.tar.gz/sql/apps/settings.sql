CREATE TABLE IF NOT EXISTS `roadphone_information` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) NOT NULL,
  `darkmode` int(11) NOT NULL DEFAULT 0,
  `flightmode` int(10) NOT NULL DEFAULT 0,
  `wallpaper` longtext DEFAULT NULL,
  `mute` int(2) DEFAULT 0,
  `lockscreen` int(2) DEFAULT 0,
  `profilepicture` LONGTEXT DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `identifier` (`identifier`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4;

ALTER TABLE `users` ADD phone_number VARCHAR(10) NULL;