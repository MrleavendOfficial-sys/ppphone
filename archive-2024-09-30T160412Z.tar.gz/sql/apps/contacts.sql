CREATE TABLE IF NOT EXISTS `roadphone_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) NOT NULL DEFAULT '0',
  `firstname` varchar(12) NOT NULL DEFAULT '0',
  `lastname` varchar(12) NOT NULL DEFAULT '0',
  `number` varchar(10) NOT NULL DEFAULT '0',
  `picture` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;