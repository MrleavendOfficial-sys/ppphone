CREATE TABLE IF NOT EXISTS `roadphone_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receiver` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `date` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isgps` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ispicture` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `picture` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;