CREATE TABLE IF NOT EXISTS `roadphone_jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(50) NOT NULL,
  `jobreceived` varchar(50) NOT NULL,
  `message` varchar(80) NOT NULL DEFAULT '0',
  `date` varchar(50) NOT NULL,
  `gps` varchar(500) DEFAULT '0',
  `status` int(2) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=200 DEFAULT CHARSET=utf8;
