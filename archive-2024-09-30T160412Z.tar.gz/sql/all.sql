CREATE TABLE IF NOT EXISTS `roadphone_camera` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) NOT NULL,
  `picture` longtext NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `roadphone_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) NOT NULL DEFAULT '0',
  `firstname` varchar(12) NOT NULL DEFAULT '0',
  `lastname` varchar(12) NOT NULL DEFAULT '0',
  `number` varchar(10) NOT NULL DEFAULT '0',
  `picture` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `roadphone_information` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) NOT NULL,
  `darkmode` int(11) NOT NULL DEFAULT 0,
  `flightmode` int(10) NOT NULL DEFAULT 0,
  `wallpaper` longtext DEFAULT NULL,
  `mute` int(2) DEFAULT 0,
  `lockscreen` int(2) DEFAULT 0,
  `profilepicture` LONGTEXT DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `identifier` (`identifier`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4;


CREATE TABLE IF NOT EXISTS `roadphone_jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(50) NOT NULL,
  `jobreceived` varchar(50) NOT NULL,
  `message` varchar(80) NOT NULL DEFAULT '0',
  `date` varchar(50) NOT NULL,
  `gps` varchar(500) DEFAULT '0',
  `status` int(2) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=200 DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `roadphone_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receiver` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `date` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isgps` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ispicture` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `picture` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `roadphone_yellowapp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `roadphone_bank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(50) NOT NULL DEFAULT '0',
  `receiver` varchar(50) NOT NULL DEFAULT '0',
  `amount` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4;

ALTER TABLE `jobs` ADD jobsapp INT(2) DEFAULT '0';
ALTER TABLE `users` ADD phone_number VARCHAR(10) NULL;

ALTER TABLE `roadphone_messages` MODIFY `date` varchar(80) NOT NULL;
CREATE TABLE IF NOT EXISTS `roadphone_calls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `caller` varchar(50) DEFAULT NULL,
  `receiver` varchar(50) DEFAULT NULL,
  `date` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;