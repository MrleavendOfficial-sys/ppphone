Config = {}

Config.ESXSharedObject = "esx:getShprimelife21aredObjprimelife21ect"
Config.ESXName = "esx:"

Config.Debug = false
Config.ItemName = "phone"
Config.NeedItem = true
Config.Command = true
Config.PhoneProp = "prop_amb_phone"
Config.ShowOffNotifications = false --Wenn du willst das alle Notifikationen die im Handy kommen auch als Notifikation außerhalb des Handys angezeigt werden stelle den Wert auf true.

Config.UseMumbleVoip = true --https://github.com/FrazzIe/mumble-voip-fivem
Config.UseTokoVoip = false
Config.UseSaltyChat = false --Funktioniert Perfekt mit Version 2.6
Config.UsePmaVoice = false

Config.defaultbackground = "../html/img/backgrounds/iphone13background.jpg" --Setzte den Hintergrund für jeden auf dem Server

--Delay
Config.Delay = 1000 --Delay wie lange man warten muss bis man das Handy erneut öffnen kann (in Millisekunden).
Config.CameraDelay = 2000 --Delay wie lange man warten muss bis man erneut ein Foto schießen kann (in Millisekunden).


Config.SQLDelay = 250 --Stell diesen Wert höher wenn in einer App bestimmte Inhalte nicht laden
Config.FirstLoadingDelay = 3000 --Stell diesen Wert höher wenn beim Joinen keine AppInhalte laden(Kontakte, Nachrichten etc) oder keine Nummer generiert wird.

--GelbeSeiten
Config.DeleteYellowAppPostsAfterRestart = false --GelbeSeiten nach Restart löschen.

--Jobs App
Config.BossName = "boss"
Config.unemployedJobName = "unemployed" --Bitte trage hier deinen Arbeitslosen Job ein damit diese nicht in der Mitarbeiter Liste angezeigt werden.
Config.ShowOnlyOnlineWorkmates = true --Stell diesen Wert auf true wenn du willst das nur Mitarbeiter die Online sind in der Jobs App angezeigt werden.

--Radio App

Config.RadioAnimation = true --TESTPHASE! / Funktioniert nur mit Mumble-Voip & PMA-Voice
Config.RadioAnimationKey = 217
Config.RemoveFromRadioWhenDead = true
Config.RadioNeedItem = false
Config.RadioItemName = "radio"

Config.lockedRadioChannels = { { frq = 1, jobhasaccess = "police4" }, { frq = 3, jobhasaccess = "fib" }, { frq = 4, jobhasaccess = "mechanic" }, { frq = 2, jobhasaccess = "ambulance"} }
