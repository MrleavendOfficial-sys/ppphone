API = {}

--Webhooks

API.PhotoWebhook = "https://ptb.discord.com/api/webhooks/945386431453462540/k-sHnJcXBeJMqfzCpqo1K4g0YzAkKtOK_aOOWsHsCgZIXVuWm4SAx_2TN_u6mQ5WHnQ7" --Zum Abspeichern der Fotos
API.YellowAppDiscordWebhook = "https://ptb.discord.com/api/webhooks/945386499837399061/wchrDMy_FyXtjf7XdoGqm3yUAuhI1otdTFG46Jo8yzhc5m9qRIOhWEuYKAOimRLWrpGb" --WARNUNG BEI DEN GELBESEITEN APP LOGS WERDEN ALLE INFORMATIONEN VOM SPIELER GELOGGT (IP,Discord,Xbox,Steam usw) DIESE INFOS SOLLEN NICHT FÜR ALLE ZUGÄNGLICH SEIN.
API.BankTransactionsWebhook = "https://ptb.discord.com/api/webhooks/945386553159598100/AYDNz_u7O36cDbG6oj79CW20pqPgPBrhTdvZv2CAhpkU-YsCkvmWjKQ-YBFJSR8yP6v6"