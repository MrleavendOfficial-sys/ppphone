phone = false
phoneId = 0
local yellowappvar = false
local contactappvar = false
local lockscreenvar = false
local messageappvar = false
local profilepicturevar = false
local messageappid = nil
local phoneanimation = false
local cameracooldown = false

RegisterNetEvent('camera:phone')
AddEventHandler('camera:phone', function(yellowapp, contactapp, messageapp, messageid, lockscreen, profilepicture)
    CreateMobilePhone(phoneId)
    CellCamActivate(true, true)
    phone = true

    if lockscreen == true then
        lockscreenvar = true
    end

    if profilepicture == true then
        profilepicturevar = true
    end

    if yellowapp == true then yellowappvar = true end
    if messageapp == true then
        messageappvar = true
        messageappid = messageid
    end

    if contactapp == true then contactappvar = true end
end)

function resetCameraVariable()
    yellowappvar = false
    messageappvar = false
    messageappid = nil
    contactappvar = false
    lockscreenvar = false
    profilepicturevar = false
end

RegisterNetEvent("camera:stoprendering")
AddEventHandler("camera:stoprendering",
                function() SendNUIMessage({action = "camerastop"}) end)

frontCam = false

function CellFrontCamActivate(activate)
    return Citizen.InvokeNative(0x2491A93618B7D838, activate)
end

TakePhoto = N_0xa67c35c56eb1bd9d
WasPhotoTaken = N_0x0d6ca79eeebd8ca3
SavePhoto = N_0x3dec726c25a11bac
ClearPhoto = N_0xd801cc02177fa3f1

Citizen.CreateThread(function()
    DestroyMobilePhone()
    while true do
        Citizen.Wait(0)
        if IsControlJustPressed(0, 27) and phone == true then
            frontCam = not frontCam
            CellFrontCamActivate(frontCam)
        end

        if phone == true then
            DisplayHelpTextThisFrame(GetCurrentResourceName(), false)
        end

        if IsControlJustPressed(0, 177) and phone == true then
            DestroyMobilePhone()
            phone = false
            CellCamActivate(false, false)
            PhonePlayOut()
            newPhoneProp()
            phoneanimation = false
            PhonePlayIn()
            if lockscreenvar == true then
                SendNUIMessage({action = "openphone", lockscreen = 1})
            else
                SendNUIMessage({action = "openphone", lockscreen = 0})
            end
            TriggerEvent('roadphone:setFocus')
            SendNUIMessage({action = "camerastop"})
            resetCameraVariable()
        end

        if IsControlJustPressed(0, 288) and phone == true then
            DestroyMobilePhone()
            phone = false
            CellCamActivate(false, false)
            PhonePlayOut()
            newPhoneProp()
            phoneanimation = false
            PhonePlayIn()
            if lockscreenvar == true then
                SendNUIMessage({action = "openphone", lockscreen = 1})
            else
                SendNUIMessage({action = "openphone", lockscreen = 0})
            end
            TriggerEvent('roadphone:setFocus')
            SendNUIMessage({action = "camerastop"})
            resetCameraVariable()
        end

        if IsControlJustPressed(0, 176) and phone == true then

            if cameracooldown == false then
                TakePhoto()
                cameracooldown = true

                dchook = roadphone.getPhotoWebhook()
                exports['screenshot-basic']:requestScreenshotUpload(dchook,
                                                                    'files[]',
                                                                    function(d)
                    local i = json.decode(d)

                    if i == nil then
                        TriggerEvent("roadphone:sendOffNotification", "Bitte kontaktieren Sie den ServerInhaber, es wurde vergessen die Webhooks einzutragen.")
                        print("Bitte kontaktieren Sie den ServerInhaber, es wurde vergessen die Webhooks einzutragen. Ohne Webhooks wird die Camera nicht richtig funktionieren.")
                        do return end
                    end
                    
                    local j = i.attachments[1].proxy_url;
                    if i.attachments and i.attachments[1] then
                        roadphone.insertPicture(j)
                        SendNUIMessage({action = "addPhotoToGallery", link = j})
                        if yellowappvar == true then
                            DestroyMobilePhone()
                            phone = false
                            CellCamActivate(false, false)
                            PhonePlayOut()
                            newPhoneProp()
                            phoneanimation = false
                            yellowappvar = false
                            SendNUIMessage({
                                action = "openYellowAppFromCamera",
                                link = j
                            })
                            PhonePlayIn()
                            TriggerEvent('roadphone:setFocus')
                            SendNUIMessage({action = "camerastop"})

                        elseif contactappvar == true then
                            DestroyMobilePhone()
                            phone = false
                            CellCamActivate(false, false)
                            PhonePlayOut()
                            newPhoneProp()
                            phoneanimation = false
                            contactappvar = false
                            SendNUIMessage({
                                action = "openContactAppFromCamera",
                                link = j
                            })
                            PhonePlayIn()
                            TriggerEvent('roadphone:setFocus')
                            SendNUIMessage({action = "camerastop"})

                        elseif messageappvar == true then
                            DestroyMobilePhone()
                            phone = false
                            CellCamActivate(false, false)
                            PhonePlayOut()
                            newPhoneProp()
                            phoneanimation = false
                            TriggerServerEvent('roadphone:sendMessage',
                                               messageappid, "", false, true, j)
                            SendNUIMessage({
                                action = "openMessageAppFromCamera",
                                chatid = messageappid
                            })
                            messageappvar = false
                            messageappid = nil
                            PhonePlayIn()
                            TriggerEvent('roadphone:setFocus')
                            SendNUIMessage({action = "camerastop"})
                        elseif profilepicturevar == true then
                            DestroyMobilePhone()
                            phone = false
                            CellCamActivate(false, false)
                            PhonePlayOut()
                            newPhoneProp()
                            phoneanimation = false
                            TriggerServerEvent("roadphone:updateProfilePicture", j)
                            SendNUIMessage({ action = "openSettingsAppFromCamera", profilepicture = j })
                            profilepicturevar = false
                            PhonePlayIn()
                            TriggerEvent('roadphone:setFocus')
                            SendNUIMessage({action = "camerastop"})
                        end

                    end
                end)

                Citizen.SetTimeout(Config.CameraDelay,
                                   function()
                    cameracooldown = false
                end)

                if (WasPhotoTaken() and SavePhoto(-1)) then
                    ClearPhoto()
                end
            else
                ESX.ShowNotification(
                    "Bitte warte bis du erneut ein Foto schießen kannst.")
            end
        end

        if phone == true then
            HideHudComponentThisFrame(7)
            HideHudComponentThisFrame(8)
            HideHudComponentThisFrame(9)
            HideHudComponentThisFrame(6)
            HideHudComponentThisFrame(19)
            HideHudAndRadarThisFrame()
        end
    end
end)
