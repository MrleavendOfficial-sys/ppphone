local isInFocus = false

Citizen.CreateThread(function()
    while true do
        if IsControlJustReleased(0, 288) then
            TriggerEvent('roadphone:openphone')
        end
        if getHandyActive() then
            if isInFocus ~= true then
                DisableControlAction(0, 304, true)
                DisableControlAction(0, 101, true)
                DisableControlAction(0, 74, true)
                DisableControlAction(0, 303, true)
                DisableControlAction(0, 311, true)
                DisableControlAction(0, 24, true)
                DisableControlAction(0, 25, true)
                DisableControlAction(0, 29, true)
                DisableControlAction(0, 1, true)
                DisableControlAction(0, 2, true)
                DisableControlAction(0, 322, true)
                DisableControlAction(0, 200, true)
                DisableControlAction(0, 202, true)
                DisableControlAction(0, 177, true)
                DisableControlAction(0, 37, true)
                DisableControlAction(0, 245, true)
                DisableControlAction(0, 263, true)
                DisableControlAction(0, 45, true)
                DisableControlAction(0, 80, true)
                DisableControlAction(0, 140, true)
                DisableControlAction(0, 0, true)
                DisableControlAction(0, 36, true)
                DisableControlAction(0, 326, true)
                DisableControlAction(0, 341, true)
                DisableControlAction(0, 343, true)
                DisableControlAction(0, 257, true)
                DisableControlAction(0, 22, true)
                DisableControlAction(0, 44, true)
                DisableControlAction(0, 288, true)
                DisableControlAction(0, 289, true)
                DisableControlAction(0, 170, true)
                DisableControlAction(0, 167, true)
                DisableControlAction(0, 26, true)
                DisableControlAction(0, 73, true)
                DisableControlAction(2, 199, true)
                DisableControlAction(0, 47, true)
                DisableControlAction(0, 264, true)
                DisableControlAction(0, 257, true)
                DisableControlAction(0, 140, true)
                DisableControlAction(0, 81, true)
                DisableControlAction(0,82, true)
                DisableControlAction(0,99, true)
                DisableControlAction(0,100,true)
                DisableControlAction(0, 141, true)
                DisableControlAction(0, 142, true)
                DisableControlAction(0, 143, true)
                DisableControlAction(0, 106, true)
                DisableControlAction(0, 245, true)
                DisableControlAction(0, 44, true)
                DisableControlAction(0, 157, true)
                DisableControlAction(0, 158, true)
                DisableControlAction(0, 160, true)
                DisableControlAction(0, 164, true)
                DisableControlAction(0, 165, true)
                DisableControlAction(0, 159, true)
                DisableControlAction(0, 161, true)
                DisableControlAction(0, 162, true)
                DisableControlAction(0, 163, true)
                DisableControlAction(0, 182, true)
                if IsPedInAnyVehicle(GetPlayerPed(-1), false) then
                    SetPlayerCanDoDriveBy(PlayerId(), false)
                end
                SetNuiFocusKeepInput(true)
            else
                SetNuiFocusKeepInput(false)
            end
        else
            SetPlayerCanDoDriveBy(PlayerId(), true)
        end
        Citizen.Wait(0)
    end
end)

Citizen.CreateThread(function()
    if Config.RemoveFromRadioWhenDead == true then
        while true do
            Citizen.Wait(1000)
            if IsEntityDead(PlayerPedId()) then
                TriggerEvent("roadphone:leaveradio")
            end
    end
end
end)
RegisterNUICallback('notification', function(data)

    local text = data.text

    -- Ersetze ESX.ShowNotification durch deine eigene Funktion/Methode wenn du möchtest das deine eigenen Notifications kommen.

    -- TriggerEvent("notifications", "#FF1D25", "Handy", text)

    ESX.ShowNotification(text)
end)

RegisterNetEvent('roadphone:sendOffNotification')
AddEventHandler('roadphone:sendOffNotification', function(text)

    -- Ersetze ESX.ShowNotification durch deine eigene Funktion/Methode wenn du möchtest das deine eigenen Notifications kommen.

    -- TriggerEvent("notifications", "#FF1D25", "Handy", text)

    ESX.ShowNotification(text)
end)

RegisterNUICallback('inputfocus', function(data) -- Nichts hier dran ändern!

    local focus = data.focus

    isInFocus = focus
end)
