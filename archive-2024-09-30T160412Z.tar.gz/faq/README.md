Das ist das Offizielle RoadPhone FAQ Version 0.4.

Frage: Was mache ich, wenn ich einen Fehler gefunden habe?

Antwort: Bitte schreiben Sie einen ausführlichen BugReport bei uns auf dem Discord in den #bug-report Kanal. Wir versuchen dann so schnell wie möglich diesen Fehler zu beheben.

##
Frage: Meine Youtube App zeigt nichts an?

Antwort: Bitte stellen Sie sicher, das Sie ihren YoutubeAPI Key in der config.json richtig eingetragen haben. Des Weiteren kann es sein das Ihr YoutubeAPI Key Limit erreicht ist. Youtube hat eine maximale Nutzung seines API Keys festgelegt ist diese erreicht kriegt RoadPhone keine Informationen mehr von Youtube und kann daher keine Videos mehr anzeigen.

##

Frage: Das Skript zeigt beim Starten "You lack the required entitlement to use roadphone"?

Antwort: Versuchen Sie, Ihren Server neu zu starten, und stellen Sie sicher, dass Ihr ServerLizenzschlüssel korrekt ist. Wenn Sie die Ressource auf dem falschen Konto gekauft haben, können Sie sie auf ein anderes Konto bei Keymaster übertragen.

##

Frage: Das Skript zeigt beim starten "Error parsing script / Failed to load script"?

Antwort: Ihre ServerVersion ist wahrscheinlich veraltet. Aktualisieren Sie Ihren Server auf Version 4752 oder höher.

##

Frage: Kann ich Apps deaktivieren?

Antwort: Ja, sie können in der apps.json im Config Ordner Apps deaktivieren (ausgenommen sind Standardapps)

##

Frage: Was kann ich tun wenn App Inhalte nicht richtig angezeigt werden?

Antwort: Gehen sie in die config.lua und stellen sie den Wert von Config.SQLDelay etwas höher und probieren Sie es erneut.

##

Frage: Meine Bilder werden nicht in der Gallery abgespeichert?

Antwort: Bitte stellen Sie sicher das sie ihre Discord Webhooks richtig in der API.lua eingetragen haben.

##

Frage: Es werden keine Jobs in der JobsApp angezeigt?

Antwort: Gehe in die jobs SQL und ändere jobsapp auf 1 und starte das Skript neu.

##

Frage: Beim starten vom Skript wird angezeigt ESX nil?

Antwort: Stelle sicher das es_extended vor RoadPhone gestartet ist und in der Config Config.ESXSharedObject richtig ist.
(Schaue dort mal in andere Skripts nach welches ESXSharedObject dort benutzt wird).

##

Frage: Wie kann ich eigene Notifications einbauen?

Antwort: Scrolle in der readme.md Datei ganz nach unten dort ist alles ausführlich erklärt.

##

Frage: Wenn ich einen Chat öffne bin ich nicht ganz unten sondern oben bei den ersten Nachrichten?

Antwort: Gehe in die config.json und erhöhe den Wert von MessageAppRefreshTime etwas und probiere es erneut.

##

Frage: Manche Bilder von meinen Usern sind nur Schwarz?

Antwort: Dies ist kein Fehler auf der Seite des Handys sondern von screenshot-basic. Wir arbeiten an einer Lösung.

##